﻿using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Windows.Forms;

namespace UniversityWebsite.App_code
{
    //**********************************************************
    //* THE CODE IN THIS CLASS CANNOT BE MODIFIED OR ADDED TO. *
    //*        Report problems to 3311rep@cse.ust.hk.          *
    //**********************************************************
    public class UniversityData
    {
        // Set the connection string to connect to the University database.
        OracleConnection UniversityDBConnection = new OracleConnection(ConfigurationManager.ConnectionStrings["UniversityConnectionString"].ConnectionString);

        // Process a SQL SELECT statement.
        public DataTable GetData(string sql)

        {
            try
            {
                if (sql.Trim() == "")
                {
                    throw new ArgumentException("The SQL statement is empty.");
                }

                DataTable dt = new DataTable();
                if (UniversityDBConnection.State != ConnectionState.Open)
                {
                    UniversityDBConnection.Open();
                    OracleDataAdapter da = new OracleDataAdapter(sql, UniversityDBConnection);
                    da.Fill(dt);
                    UniversityDBConnection.Close();
                }
                else
                {
                    OracleDataAdapter da = new OracleDataAdapter(sql, UniversityDBConnection);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (OracleException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        // Process an SQL SELECT statement that returns only a single value.
        // Returns 0 if the table is empty or the column has no values.
        public decimal GetAggregateValue(string sql)
        {
            try
            {
                if (sql.Trim() == "")
                {
                    throw new ArgumentException("The SQL statement is empty.");
                }
                object aggregateValue;
                if (UniversityDBConnection.State != ConnectionState.Open)
                {
                    UniversityDBConnection.Open();
                    OracleCommand SQLCmd = new OracleCommand(sql, UniversityDBConnection);
                    SQLCmd.CommandType = CommandType.Text;
                    aggregateValue = SQLCmd.ExecuteScalar();
                    UniversityDBConnection.Close();
                }
                else
                {
                    OracleCommand SQLCmd = new OracleCommand(sql, UniversityDBConnection);
                    SQLCmd.CommandType = CommandType.Text;
                    aggregateValue = SQLCmd.ExecuteScalar();
                }
                return (DBNull.Value == aggregateValue ? 0 : Convert.ToDecimal(aggregateValue));
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (OracleException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return -1;
        }

        // Process SQL INSERT, UPDATE and DELETE statements.
        public void SetData(string sql, OracleTransaction trans)
        {
            try
            {
                if (sql.Trim() == "")
                {
                    throw new ArgumentException("The SQL statement is empty.");
                }

                OracleCommand SQLCmd = new OracleCommand(sql, UniversityDBConnection);
                SQLCmd.Transaction = trans;
                SQLCmd.CommandType = CommandType.Text;
                SQLCmd.ExecuteNonQuery();
            }
            catch (ArgumentException ex)
            {
                UniversityDBConnection.Close();
                MessageBox.Show(ex.Message);
            }
            catch (ApplicationException ex)
            {
                UniversityDBConnection.Close();
                MessageBox.Show(ex.Message);
            }
            catch (OracleException ex)
            {
                UniversityDBConnection.Close();
                MessageBox.Show(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                UniversityDBConnection.Close();
                MessageBox.Show(ex.Message);
            }
        }

        public OracleTransaction BeginTransaction()
        {
            if (UniversityDBConnection.State != ConnectionState.Open)
            {
                UniversityDBConnection.Open();
                OracleTransaction trans = UniversityDBConnection.BeginTransaction();
                return trans;
            }
            else
            {
                OracleTransaction trans = UniversityDBConnection.BeginTransaction();
                return trans;
            }
        }

        public void CommitTransaction(OracleTransaction trans)
        {
            try
            {
                if (UniversityDBConnection.State == ConnectionState.Open)
                {
                    trans.Commit();
                    UniversityDBConnection.Close();
                }
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (OracleException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}