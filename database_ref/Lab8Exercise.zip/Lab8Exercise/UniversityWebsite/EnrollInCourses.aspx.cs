﻿using Oracle.DataAccess.Client;
using System;
using System.Data;
using System.Web.UI.WebControls;
using UniversityWebsite.App_code;

public partial class EnrollInCourses : System.Web.UI.Page
{
    UniversityData myWebsiteData = new UniversityData();
    private DataTable dtCourse;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnFindAvailabelCourses_Click(object sender, EventArgs e)
    {
        // Hide the search result message.
        lblResultMessage.Visible = false;
        gvAvailableCourses.Visible = false;
        string studentId = txtStudentID.Text.Trim();

        if ((studentId != "") && (studentId.Length == 8))
        {
            //******************************************************************************************
            // TODO: Construct the SELECT statement to find the courses available for the student with *
            //       studentId to enroll in. Show only courses that the student is not enrolled in.    *
            //******************************************************************************************
            string sql = "";

            // Execute the SQL statement and place the result in a datatable.
            dtCourse = myWebsiteData.GetData(sql);

            // Fill the GridView from the datatable and bind the search result to the GridView control.
            gvAvailableCourses.DataSource = dtCourse;
            gvAvailableCourses.DataBind();

            // Display a no result message if nothing was retrieved from the database.
            if (gvAvailableCourses.Rows.Count == 0)
            {
                lblResultMessage.Text = "There are no courses available for you to enroll in.";
            }
            else
            {
                gvAvailableCourses.Visible = true;
                lblResultMessage.Text = "The following courses are available for you to enroll in:";
                btnSubmit.Visible = true;
            }
        }
        else
        {
            lblResultMessage.Text = "Please enter a valid student id.";
        }
        lblResultMessage.Visible = true;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        lblResultMessage.Visible = false;
        btnSubmit.Visible = false;
        gvAvailableCourses.Visible = false;
        string studentId = txtStudentID.Text.Trim();
        int coursesEnrolled = 0;

        // Search each row of the GridView to determine if any courses were selected.
        foreach (GridViewRow row in gvAvailableCourses.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                if (chkRow != null && chkRow.Checked)
                {
                    coursesEnrolled = coursesEnrolled + 1;
                    // Get the course id of the selected course.
                    string courseId = row.Cells[1].Text.Trim();

                    //*************************************************************************************
                    // TODO: Construct the INSERT statement to enroll the student in the selected course. *
                    //*************************************************************************************
                    string sql = "";

                    // Execute the SQL INSERT statement.
                    OracleTransaction trans = myWebsiteData.BeginTransaction();
                    myWebsiteData.SetData(sql, trans);
                    myWebsiteData.CommitTransaction(trans);
                }
            }

            // Display a message indicating result of enrollment.
            if (coursesEnrolled != 0)
            {
                if (coursesEnrolled == 1)
                {
                    lblResultMessage.Text = "You have successfully enrolled in "
                        + coursesEnrolled.ToString() + " course.";
                }
                else
                {
                    lblResultMessage.Text = "You have successfully enrolled in "
                        + coursesEnrolled.ToString() + " courses.";
                }
            }
            else
            {
                lblResultMessage.Text = "You have not been enrolled in any courses.";
            }
        }
        lblResultMessage.Visible = true;
    }
}