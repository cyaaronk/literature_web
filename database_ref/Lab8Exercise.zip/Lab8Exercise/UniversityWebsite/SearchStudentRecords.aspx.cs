﻿using System;
using System.Data;
using UniversityWebsite.App_code;

public partial class SearchStudentRecords : System.Web.UI.Page
{
    UniversityData myWebsiteData = new UniversityData();
    private DataTable dtStudent;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        // Hide the search result message.
        lblSearchResultMessage.Visible = false;
        gvStudentSearchResult.Visible = false;

        // Get the department id from the search page.
        string departmentId = txtDepartmentId.Text.Trim().ToUpper();

        if (departmentId != "")
        {
            //****************************************************************
            // TODO: Construct the SELECT statement for finding the students *
            //       in the department with the specified departmentId.      *
            //****************************************************************
            string sql = "";

            // Execute the SQL statement and place the result in a datatable.
            dtStudent = myWebsiteData.GetData(sql);

            // Fill the GridView from the datatable and bind the search result to the GridView control.
            gvStudentSearchResult.DataSource = dtStudent;
            gvStudentSearchResult.DataBind();

            // Display a no result message if nothing was retrieved from the database.
            if (gvStudentSearchResult.Rows.Count != 0)
            {
                gvStudentSearchResult.Visible = true;
                lblSearchResultMessage.Text = "The following students are in the " + departmentId + " department:";
            }
            else
            {
                lblSearchResultMessage.Text = "There are no students in the " + departmentId + " department.";
            }
        }
        else
        {
            lblSearchResultMessage.Text = "Please enter a department id.";
        }
        lblSearchResultMessage.Visible = true;
    }
}