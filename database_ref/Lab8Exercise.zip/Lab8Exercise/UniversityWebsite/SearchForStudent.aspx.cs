﻿using System;
using System.Data;
using UniversityWebsite.App_code;

public partial class SearchForStudent : System.Web.UI.Page
{
    UniversityData myWebsiteData = new UniversityData();
    private DataTable dtCourse;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnFindAvailabelCourses_Click(object sender, EventArgs e)
    {
        // Hide the search result message.
        lblResultMessage.Visible = false;
        gvStudentRecord.Visible = false;
        string studentId = txtStudentID.Text.Trim();

        if ((studentId != "") && (studentId.Length == 8))
        {
            //****************************************************
            // TODO: Construct the SELECT statement to find the  *
            //       student record with the specified studentId.*
            //****************************************************
            string sql = "select * from student where student_id='" + studentId + "'";

            // Execute the SQL statement and place the result in a datatable.
            dtCourse = myWebsiteData.GetData(sql);

            // Fill the GridView from the datatable and bind
            // the search result to the GridView control.
            gvStudentRecord.DataSource = dtCourse;
            gvStudentRecord.DataBind();

            // Display a no result message if nothing was retrieved from the database.
            if (gvStudentRecord.Rows.Count == 0)
            {
                lblResultMessage.Text = "The student record was not found.";
            }
            else
            {
                gvStudentRecord.Visible = true;
                lblResultMessage.Text = "The following student record was found:";
            }
        }
        else
        {
            lblResultMessage.Text = "Please enter a valid student id.";
        }
        lblResultMessage.Visible = true;
    }
}